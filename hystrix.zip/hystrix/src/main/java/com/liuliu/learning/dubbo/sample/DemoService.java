package com.liuliu.learning.dubbo.sample;

public interface DemoService {
	String sayHello(String name);
}